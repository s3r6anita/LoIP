require "test_helper"

class SeqControllerTest < ActionDispatch::IntegrationTest
  test "should get input" do
    get seq_input_url
    assert_response :success
  end

  test "should get view" do
    get seq_view_url
    assert_response :success
  end
end
