# frozen_string_literal: true

def correct(arr)
  found = []
  tmp_found = []

  arr.take(arr.size - 1).each_index do |i|
    tmp_found << arr[i]
    unless arr[i] < arr [i + 1]
      found << tmp_found
      tmp_found = []
    end
  end

  tmp_found << arr[-1]
  found << tmp_found

  sizes = found.map(&:size)

  @max_found = found[sizes.index(sizes.max)].join(' ')
  @found = found.map { |x| x.join(' ') }.join(' | ')
end

# Top-level class
class SeqController < ApplicationController

  def input
  end

  def view
    not(params[:str]) || params[:str]=='' ? @str = 'Error' : @str = params[:str]
    @max_found = @str
    @found = @str
    arr = @str&.split&.map(&:to_i)
    arr && !arr&.empty? ? correct(arr) : nil

    respond_to do |format|
      format.html
      format.js
    end
    
  end
end

