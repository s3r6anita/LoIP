module SeqHelper
end
