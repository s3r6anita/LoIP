# frozen_string_literal: true

def correct (arr)
  found = []
  tmp_found = []

  arr.take(arr.size - 1).each_index do |i|
    if arr[i] < arr [i+1] 
      tmp_found << arr[i] 
    else
      tmp_found << arr[i]
      found << tmp_found
      tmp_found = []
    end 
  end

  tmp_found << arr[-1]
  found << tmp_found

  sizes = found.map { |x| x.size }

  @max_found = found[sizes.index(sizes.max)].join(' ')
  @found = found.map { |x| x.join(' ') }.join(' | ')

end

class SeqController < ApplicationController

  def input
  end

  def show
    @str = params[:str]
    @max_found, @found = @str, @str
    arr = @str&.split&.map(&:to_i)
    arr && not(arr&.empty?) ? correct(arr) : nil
  end
end
