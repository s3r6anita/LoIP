# frozen_string_literal: true

require 'test_helper'

class TransControllerTest < ActionDispatch::IntegrationTest
  test 'should get render' do
    get 'http://localhost:3001/trans/render_xml', params: { arr: (1..9).to_a, max: (1..9).to_a, found: (1..9).to_s, format: 'html' }
    assert_response :success
  end

  test 'should render html' do
    get 'http://localhost:3001/trans/render_xml', params: { arr: (1..9).to_a, max: (1..9).to_a, found: (1..9).to_s, format: 'html' }
    assert_empty(Nokogiri::HTML(@response.body).errors)
  end

  test 'should render xml' do
    get 'http://localhost:3001/trans/render_xml', params: { arr: (1..9).to_a, max: (1..9).to_a, found: (1..9).to_s, format: 'xml' }
    assert_empty(Nokogiri::XML(@response.body).errors)
  end
end
