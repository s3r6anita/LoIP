# frozen_string_literal: true

require 'net/http'
require 'nokogiri'

# top-level documentation
class TransController < ApplicationController
  def input; end

  def render_xml
    return unless params[:arr] && params[:max]

    tmp = []
    tmp << params[:arr].map(&:to_i)
    tmp << params[:max].map(&:to_i)
    tmp << params[:found]

    @xml = Nokogiri::XML(tmp.to_xml)

    @xml.root.add_previous_sibling Nokogiri::XML::ProcessingInstruction.new(@xml, 'xml-stylesheet',
                                                                            'type="text/xsl" href="/xml_styler.xslt"')

    respond_to do |format|
      format.xml { render xml: @xml, layout: false }
      format.html do
        xslt = Nokogiri::XSLT(IO.read("#{Rails.root}/public/xml_styler.xslt"))
        result = Nokogiri::HTML5(xslt.transform(@xml).to_s)
        render xml: result.to_s
      end
    end
  end
end
