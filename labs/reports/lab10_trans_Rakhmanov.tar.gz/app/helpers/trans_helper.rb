# frozen_string_literal: true

# top-level documentation
module TransHelper
end
