# frozen_string_literal: true

# top-level documentation
class UsersController < ApplicationController
  def show
    @user = current_user
  end

  def show_all
    @users = User.all
  end
end
