# frozen_string_literal: true

# Top-level class
class SeqController < ApplicationController
  before_action :authenticate_user!
  def input; end

  def show
    params[:str] ? @str = params[:str] : nil

    arr = @str.split&.map(&:to_i)

    if arr && !arr&.empty?
      tmp = helpers.find_seqs(arr)
      @found = tmp.map { |x| x.join(' ') }.join(' | ')
      @max_found = helpers.find_max(tmp)
    else
      @max_found = @str
      @found = @str
    end
  end

  private

  def authenticate_user!
    if user_signed_in?
      puts "User #{current_user} is authenticated"
    else
      puts "User isn't authenticated"
      redirect_to new_user_session_path
    end
  end
end
