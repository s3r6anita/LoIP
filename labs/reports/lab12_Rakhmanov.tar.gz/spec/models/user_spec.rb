# frozen_string_literal: true

require 'spec_helper'
require 'rails_helper'

RSpec.describe Devise, type: :system do
  let(:email_user) { 'gar@amir.tat' }
  let(:password_user) { 'fweu98254jkbfwbiuygbwoiuybvSYHIUEF' }
  describe 'User sign up' do
    scenario 'sign up without params' do
      visit new_user_registration_path
      click_button 'Sign up'
      expect(page).to have_content("errors prohibited this user from being saved:\nEmail can't be blank\nPassword can't be blank\n")
    end

    scenario 'sign up without email' do
      visit new_user_registration_path
      fill_in 'Password', with: password_user
      fill_in 'Password confirmation', with: password_user
      click_button 'Sign up'
      expect(page).to have_content("error prohibited this user from being saved:\nEmail can't be blank\n")
    end

    scenario 'sign up without password' do
      visit new_user_registration_path
      fill_in 'Email', with: email_user
      fill_in 'Password confirmation', with: password_user
      click_button 'Sign up'
      expect(page).to have_content("Password confirmation doesn't match Password\n")
    end

    scenario 'sign up, but password confirmation does not match password' do
      visit new_user_registration_path
      fill_in 'Email', with: email_user
      fill_in 'Password', with: password_user
      fill_in 'Password confirmation', with: "#{password_user}1"
      click_button 'Sign up'
      expect(page).to have_content("Password confirmation doesn't match Password\n")
    end

    scenario 'sign up with correct params' do
      visit new_user_registration_path
      fill_in 'Email', with: email_user
      fill_in 'Password', with: password_user
      fill_in 'Password confirmation', with: password_user
      click_button 'Sign up'
      expect(page).to have_content("Welcome! You have signed up successfully.\n")
    end
  end

  describe 'User sign in' do
    before :each do
      visit new_user_registration_path
      fill_in 'Email', with: email_user
      fill_in 'Password', with: password_user
      fill_in 'Password confirmation', with: password_user
      click_button 'Sign up'
      click_link 'Log out'
    end

    scenario 'sign in without params' do
      visit new_user_session_path
      click_button 'Log in'
      expect(page).to have_content("Invalid Email or password.\n")
    end

    scenario 'sign in with params' do
      fill_in 'Email', with: email_user
      fill_in 'Password', with: password_user
      click_button 'Log in'
      expect(page).to have_content("Signed in successfully.\n")
    end

    scenario 'sign in with params and make calculations' do
      fill_in 'Email', with: email_user
      fill_in 'Password', with: password_user
      click_button 'Log in'
      fill_in 'input', with: '1 2 3 4 3 4 5 1 1 1 5 3 4 5 6 10 0 -1 -3'
      click_button 'Correct and print'
      expect(page).to have_current_path('/seq/show?str=1+2+3+4+3+4+5+1+1+1+5+3+4+5+6+10+0+-1+-3&commit=Correct+and+print')
    end
  end

  describe 'User try to make calculations' do
    scenario 'failure make calculations' do
      visit '/seq/show?str=1+2+3+4+3+4+5+1+1+1+5+3+4+5+6+10+0+-1+-3&commit=Correct+and+print'
      expect(page).to have_current_path(new_user_session_path)
    end
  end
end
