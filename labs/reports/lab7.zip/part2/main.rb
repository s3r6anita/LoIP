# freeze_string_literal: true

# Class for an ordinary window
class Window
  def initialize(_l, _w)
    @len = _l
    @wid = _w
  end

  def square
    @len * @wid
  end
end

# Class for an professional window
class Blind < Window
  def initialize(_l, _w, _b)
    @bld = true?(_b)
    super(_l, _w)
  end

  def true?(str)
    str.downcase == 'true'
  end

  def is_blind?
    @bld ? true : false
  end
end
