# frozen_string_literal: true

# top-level documentation
class CreateSequences < ActiveRecord::Migration[7.0]
  def change
    create_table :sequences do |t|
      t.string :given
      t.string :max_seq
      t.string :all_seq

      t.timestamps
    end
  end
end
