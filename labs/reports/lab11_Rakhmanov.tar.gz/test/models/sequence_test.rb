# frozen_string_literal: true

require 'test_helper'

# top-level documentation
class SequenceTest < ActiveSupport::TestCase
  test 'cannot save twice' do
    res = Sequence.create given: '1 2 3', max_seq: '1 2 3', all_seq: '1 2 3'
    res.save
    res = Sequence.create given: '1 2 3', max_seq: '0 1 2 3', all_seq: '1 2 3'
    res.save
    res = Sequence.find_by_given('1 2 3')
    assert_equal(res.max_seq, '1 2 3')
  end
end
