# frozen_string_literal: true

require 'test_helper'

TEST_DATA = [
  {
    input: { str: '1 2 3 4 3 4 5 1 1 1 5 3 4 5 6 10 0 -1 -3' },
    output: ['1 2 3 4 3 4 5 1 1 1 5 3 4 5 6 10 0 -1 -3', '3 4 5 6 10',
             '1 2 3 4 | 3 4 5 | 1 | 1 | 1 5 | 3 4 5 6 10 | 0 | -1 | -3']
  },
  {
    input: { str: '1 2 3 4 1 2 3 1 2' },
    output: ['1 2 3 4 1 2 3 1 2', '1 2 3 4', '1 2 3 4 | 1 2 3 | 1 2']
  },
  {
    input: { str: '38 23 20 28 49 22 39 9 3 56 4' },
    output: ['38 23 20 28 49 22 39 9 3 56 4', '20 28 49', '38 | 23 | 20 28 49 | 22 39 | 9 | 3 56 | 4']
  }
].freeze

# Top-level class
class SeqControllerTest < ActionDispatch::IntegrationTest
  test 'should get show' do
    get '/seq/show'
    assert_response :success
  end

  test 'should get input' do
    get '/'
    assert_response :success
  end

  test 'should return empty result' do
    input = { str: '' }
    get "/seq/show?#{input.to_query}"
    assert_equal('', assigns(:str))
    assert_equal('', assigns(:max_found))
    assert_equal('', assigns(:found))
  end

  test 'should return correct data' do
    TEST_DATA.each do |data|
      input = data[:input]
      output = data[:output]
      get "/seq/show?#{input.to_query}"
      assert_equal(output[0], assigns(:str))
      assert_equal(output[1], assigns(:max_found))
      assert_equal(output[2], assigns(:found))
    end
  end

  test 'different data' do
    input1 = TEST_DATA[0][:input]
    input2 = TEST_DATA[1][:input]
    get "/seq/show?#{input1.to_query}"
    a = [assigns(:str), assigns(:max_found), assigns(:found)]
    # aa = assigns(:max_found)
    get "/seq/show?#{input2.to_query}"
    b = [assigns(:str), assigns(:max_found), assigns(:found)]
    # bb = assigns(:max_found)
    # assert_not_equal(aa, bb)

    a.each_index do |i|
      assert_not_equal(a[i], b[i])
    end
  end

  # test "should get 11 for view with with 1+10" do
  #   get '/seq/show', params: {v1: 1, v2: 10, op: '+'}
  #   assert_equal(assigns[:result], 11)
  # end

  # test "should get Unknown! for incorrect params" do
  #   get '/seq/show'
  #   assert_equal(assigns[:result], 'Unknown!')
  # end
end
