# frozen_string_literal: true

class Sequence < ApplicationRecord
  validates_uniqueness_of :given
end
