# frozen_string_literal: true

# Top-level class
class SeqController < ApplicationController
  def input; end

  def last
    @str = Sequence.last
  end

  def base
    @str = Sequence.all
  end

  def xml_str
    str = Sequence.all
    res = str.map { |s| [JSON.parse(s.given).to_s, JSON.parse(s.max_seq).to_s, JSON.parse(s.all_seq).to_s] }
    render xml: res.to_xml
  end

  def show
    params[:str] ? @str = params[:str] : nil

    res = Sequence.find_by_given(ActiveSupport::JSON.encode(@str))

    if res
      @source = 'DataBase'
      @max_found = ActiveSupport::JSON.decode(res.max_seq)
      @found = ActiveSupport::JSON.decode(res.all_seq)
    else
      @source = 'Calculation'

      arr = @str&.split&.map(&:to_i)

      if arr && !arr&.empty?
        tmp = helpers.find_seqs(arr)
        @found = tmp.map { |x| x.join(' ') }.join(' | ')
        @max_found = helpers.find_max(tmp)
      else
        @max_found = @str
        @found = @str
      end

      res = Sequence.create given: ActiveSupport::JSON.encode(@str), max_seq: ActiveSupport::JSON.encode(@max_found),
                            all_seq: ActiveSupport::JSON.encode(@found)
      res.save
    end
  end
end
