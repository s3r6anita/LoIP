# frozen_string_literal: true

# top-level documentation
module SeqHelper
  def find_seqs(arr)
    found = []
    tmp_found = []

    arr.take(arr.size - 1).each_index do |i|
      tmp_found << arr[i]
      unless arr[i] < arr [i + 1]
        found << tmp_found
        tmp_found = []
      end
    end

    tmp_found << arr[-1]
    found << tmp_found
    p found
    found
  end

  def find_max(alr_found)
    sizes = alr_found.map(&:size)
    alr_found[sizes.index(sizes.max)].join(' ')
  end
end
