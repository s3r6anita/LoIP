# frozen_string_literal: true

# top-level documentation
module ApplicationHelper
end
