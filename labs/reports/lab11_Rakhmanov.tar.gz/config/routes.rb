# frozen_string_literal: true

Rails.application.routes.draw do
  root 'seq#input', as: :home
  get 'seq/show'
  get 'seq/base'
  get 'seq/last'
  get 'seq/xml_str'
  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html

  # Defines the root path route ("/")
  # root "articles#index"
end
